# -*- coding: utf-8 -*-

from . import tempo_parte
from . import partner
from . import subscricao
from . import pagamento
from . import socio
from . import escalao
from . import atleta
from . import seccionista
from . import treinador
from . import licenca_desportiva
from . import local
from . import epoca
from . import categoria_treino
from . import equipa
from . import dados_antropometricos
from . import testes_fisicos
from . import evento_desportivo
from . import planeamento
from . import jogo
from . import treino
from . import pai
from . import lesao
from . import competicao
from . import equipa_adversaria
from . import zona
from . import massagista