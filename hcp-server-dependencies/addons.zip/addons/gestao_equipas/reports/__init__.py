# -*- coding: utf-8 -*-

from . import horario_report
from . import horario_report_atleta
from . import horario_report_treinador
from . import horario_report_seccionista
from . import mapa_report
from . import reg_presencas_report
from . import folha_convoc_report
from . import mapa_presencas_geral_report
from . import mapa_presencas_atleta_report
from . import carga_fisica_report